# <center>dustbin|wiki</center>

<center><img src="/assets/logo.jpg" width="35%"/></center>
<center><img src="https://q1.qlogo.cn/g?b=qq&nk=180441305&s=640" width="20%"/></center>


<center>微尘Dust</center>

---

### 微尘Dust(又称dustbin、紫水晶)

微尘的外号**紫水晶**来自他于小学时期(大概2020年)时制作的头像

在2025年8月5日发布于紫水晶批发市场的活动中

[云里是个太阳](?page=wiki/sunpromax)在picrew热门狂翻28页

找到了紫水晶的头像制作页(见:[wiki:寻找紫水晶](?page=wiki/findofdustbin))

以及后来的[JuX](?page=wiki/jux)与[Howie](?page=wiki/howie)逆向网站

而“**紫水晶**”起初来源于[sajvwm](?page=wiki/sajvwm)的奇思妙想...
<details>
<summary>紫水晶对比图</summary>
微尘头像(旧):

<center><img src="/assets/dustbin.png" width="35%"/></center>

sajvwm的奇思妙想:

<center><img src="/assets/sajvwmsthink.jpg" width="65%"/></center>

</details>



(本页面是wiki词条，有关的逆天聊天记录请[点击查看](doc/dustbin))