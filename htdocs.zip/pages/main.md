# <center>GROUP SHIT RECORD</center>

<center><img src="/assets/logo.jpg" width="35%"/></center>

<center>欢迎来到 ShitHub</center>

---
收录群聊**呱呱小分队**与**紫水晶批发市场**中的逆天聊天记录

*主要人物(点击查看聊天记录):*
  - [sajvwm](?page=doc/sajvwm)
  - [微尘Dust](?page=doc/dustbin)
  - [云里是个太阳](?page=doc/sunpromax)
  - [棍母](?page=doc/dghj)

*wiki:[wiki页面](?page=wiki/wiki)*