$(document).ready(function() {
  const article = $("#page > .article");
  const passage = article.children();
  
  passage.each(function(i, el) {
    let e = $(el);
    console.log(e.prop("tagName"));
    
    // 通用处理：如果有center属性，则添加center类
    if (e.attr("center") !== undefined) {
      e.addClass("center");
    }
    let inner;
    // 然后根据标签名做特殊处理
    switch(e.prop("tagName")) {
      case "SHITHUBIMG":
        e.addClass("shElement");
        const src = e.attr("src");
        const height = e.attr("height");
        const width = e.attr("width");
        
        inner = "<img class=\"shimg\" ";
        inner += (src ? "src=\"" + src + "\" " : "");
        inner += (height ? "height=\"" + height + "\" " : "");
        inner += (width ? "width=\"" + width + "\" " : "");
        inner += "/>";
        
        e.html(inner);
        break;
      case "SHITHUBTEXT":
        e.addClass("shElement");
        break;
      case "SHITHUBH1":
        e.addClass("shElement");
        e.addClass("header1");
        inner = "<h1 class=\"shh1\">";
        inner+=e.text();
        inner+="</h1>"
        e.html(inner);
        break;
      case "SHITHUBH2":
        e.addClass("shElement");
        e.addClass("header2");
        inner = "<h2 class=\"shh1\">";
        inner+=e.text();
        inner+="</h2>"
        e.html(inner);
        break;
    }
  });
});