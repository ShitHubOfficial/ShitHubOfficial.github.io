# <center>howei|wiki</center>

<center><img src="/assets/logo.jpg" width="35%"/></center>
<center><img src="https://q1.qlogo.cn/g?b=qq&nk=2110592173&s=640" width="20%"/></center>


<center>Howei114514</center>

---

### Howie(又称屎山大师)


(本页面是wiki词条，有关的逆天聊天记录请[点击查看](?page=doc/sajvwm))