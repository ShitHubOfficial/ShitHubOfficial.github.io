# <center>sajvwm|wiki</center>

<center><img src="/assets/logo.jpg" width="35%"/></center>
<center><img src="https://q1.qlogo.cn/g?b=qq&nk=1129519322&s=640" width="20%"/></center>


<center>sajvwm</center>

---

### sajvwm(又称saj3627、蓝铜)


(本页面是wiki词条，有关的逆天聊天记录请[点击查看](?page=doc/sajvwm))